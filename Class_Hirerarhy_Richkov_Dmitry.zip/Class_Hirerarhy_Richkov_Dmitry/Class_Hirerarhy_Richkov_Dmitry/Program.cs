﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hirerarhy_Richkov_Dmitry
{
    class Program
    {
        public const int SIZE = 3;
        static void Main(string[] args)
        {
            ObjectOutput();
        }

        static void ObjectOutput()
        {
            var automobiles = new List<Autmobile>();
            automobiles.Add(new Car("Corolla", 210, 150, "Sedan", "Automatic"));
            automobiles.Add(new Truck(1500, "TGX", 120, 400));
            automobiles.Add(new PublicTransport(30, "Next", 110, 210));

            Console.WriteLine("Для просмотра характеритик Toyota нажмите 1");
            Console.WriteLine("Для просмотра характеритик Man нажмите 2");
            Console.WriteLine("Для просмотра характеритик Gaz нажмите 3");
            Console.WriteLine("Нажмите 4 для выхода");

            bool flag = true;
            while (flag)
            {

                try
                {
                    int x = int.Parse(Console.ReadLine());

                    switch (x)
                    {
                        case 1:
                            Console.WriteLine(automobiles[0]);
                            break;
                        case 2:
                            Console.WriteLine(automobiles[1]);
                            break;
                        case 3:
                            Console.WriteLine(automobiles[2]);
                            break;
                        case 4:
                            flag = false;
                            break;
                        default:
                            Console.WriteLine("Введено неверное значение");
                            break;
                    }
                   
                }
                catch (FormatException)
                {
                    Console.WriteLine("Введите значение от 1 до 3");
                }
            }
            Console.ReadLine();
        }
    }
}
