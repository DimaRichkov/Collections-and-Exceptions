﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Hirerarhy_Richkov_Dmitry
{
    class Truck : Autmobile
    {
        private int carrying;

        public int Carrying
        {
            get
            {
                return carrying;
            }

            set
            {
                carrying = value;
            }
        }

        public Truck(int carrying, string model, int speed, int power)
        {
            this.carrying = carrying;
            this.model = model;
            this.speed = speed;
            this.power = power;
        }

        private void Loading()
        {

        }

        private void Unloading()
        {

        }

        public override void Acceleration()
        {
            throw new NotImplementedException();
        }

        public override void Brake()
        {
            throw new NotImplementedException();
        }

        public override void EngineStart()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return base.ToString() + "; Carrying: " + Carrying.ToString();
        }
    }
}
